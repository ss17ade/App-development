//
//  GameOVerViewController.swift
//  16061957
//
//  Created by ss17ade on 03/01/2020.
//  Copyright © 2020 ss17ade. All rights reserved.
//

import UIKit

class GameOVerViewController: UIViewController {

    @IBOutlet weak var lblGameOver: UILabel!
    @IBOutlet weak var lblLevel: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    var userLevel: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        getUserScoreAndLevel()
        checkGameOver()
    }
    func getUserScoreAndLevel(){
        if let score = UserDefaults.standard.string(forKey: "userScore"), let level = UserDefaults.standard.string(forKey: "userLevel"){
            self.lblScore.text = score
            self.lblLevel.text = level
            self.userLevel = Int(level)!
        }
        
    }
    
    func checkGameOver(){
        if self.userLevel == 3 {
            self.lblGameOver.isHidden = false
        }
    }
    
    @IBAction func replayPressed(_ sender: Any) {
        //Removing userdefaults
        UserDefaults.standard.removeObject(forKey: "userScore")
        
        //Level range upto 3 only
        if self.userLevel >= 3 {
            UserDefaults.standard.removeObject(forKey: "userLevel")
        } else {
            //increasing levels
            if self.userLevel != 0 {
                self.userLevel += 1
                UserDefaults.standard.set(String(self.userLevel), forKey: "userLevel")
            }
        }
        
        
        let main = UIStoryboard(name: "Main", bundle: nil)
        let gameVC = main.instantiateViewController(withIdentifier: "GameVC")
        self.present(gameVC, animated: true, completion: nil)
    }
}
