//
//  ViewController.swift
//  16061957
//
//  Created by ss17ade on 03/01/2020.
//  Copyright © 2020 ss17ade. All rights reserved.
//

import UIKit
import AudioToolbox
import AVFoundation

class ViewController: UIViewController, UICollisionBehaviorDelegate {
    var animator: UIDynamicAnimator!
    var gravity: UIGravityBehavior!
    var collisionSquare: UICollisionBehavior!
    var collisionImage: UICollisionBehavior!
    var force : UIPushBehavior!
    var firstContact = false
    var snap: UISnapBehavior!
    var birdTimer : Timer!
    var viewTimer : Timer!
    var levelTimer: Timer!
    var topWall : UIView!
    var bottomWall : UIView!
    var birdView1 : UIImageView!
    var score: Int = 0
    var obstacleImgView: UIImageView!
    var imagesArray : [UIImage] = [UIImage.init(named: "bird1")!,UIImage.init(named: "bird2")!,
    UIImage.init(named: "bird3")!,UIImage.init(named: "bird4")!,
    UIImage.init(named: "bird5")!,UIImage.init(named: "bird6")!,
    UIImage.init(named: "bird7")!,UIImage.init(named: "bird8")!,
    UIImage.init(named: "bird9")!,UIImage.init(named: "bird10")!,
    UIImage.init(named: "bird11")!,UIImage.init(named: "bird12")!,
    UIImage.init(named: "bird13")!]
    var notificationSoundLookupTable = [String: SystemSoundID]()
    
    let birdsImagesArray = [UIImage.init(named: "bird1"), UIImage.init(named: "bird2"),UIImage.init(named: "bird3"),UIImage.init(named: "bird4"),UIImage.init(named: "bird5"),UIImage.init(named: "bird6"),UIImage.init(named: "bird7"),]
    var birdImageViews : [UIImageView] = []
    var ballsArray : [UIImageView] = []
    var backgroundMusic: AVAudioPlayer?
    
    func music(){
    let path = Bundle.main.path(forResource: "backgroundMusic.mp3", ofType:nil)!
    let url = URL(fileURLWithPath: path)
    
        do{
        backgroundMusic = try AVAudioPlayer(contentsOf: url)
        backgroundMusic?.setVolume(1, fadeDuration: 2)
                backgroundMusic?.play()
            } catch {
                //no load
            }
        }
            
            
    @IBOutlet var bird5: UIImageView!
    @IBOutlet var bird4: UIImageView!
    @IBOutlet var bird3: UIImageView!
    @IBOutlet var bird2: UIImageView!
    @IBOutlet var bird1: UIImageView!
    @IBOutlet var btnAim: UIButton!
    //@IBOutlet var leftWall: UIView!
    //@IBOutlet var rightWall: UIView!
    //@IBOutlet var bottomWall: UIView!
    //@IBOutlet var topWall: UIView!
    @IBOutlet var lblLevel: UILabel!
    
    @IBOutlet var lblScore: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.createPanGestureRecognizer(targetView: self.btnAim)
        
        birdTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.animateBirds), userInfo: nil, repeats: true)
        
        topWall = UIView(frame: CGRect(x: 0, y: -20, width: self.view.frame.width, height: 20))
        view.addSubview(topWall)
        
        bottomWall = UIView(frame: CGRect(x: 00, y: self.view.frame.height, width: self.view.frame.width, height: 20))
        view.addSubview(bottomWall)
        
        birdView1 = UIImageView(frame: CGRect(x: self.view.frame.size.width - 100, y: 0, width: 100, height: self.view.frame.size.height))
        //birdView1.image = UIImage.init(named: "bird1")
        view.addSubview(birdView1)
        
        //Initilizing Animator
        animator = UIDynamicAnimator(referenceView: view)
        
        //Adding Image collision
        collisionImage = UICollisionBehavior(items: [birdView1])
        collisionImage.collisionMode = .boundaries
        collisionImage.addBoundary(withIdentifier: "bottomWall" as NSString, for: UIBezierPath(rect: bottomWall.frame))
        collisionImage.addBoundary(withIdentifier: "topWall" as NSString, for: UIBezierPath(rect: topWall.frame))
        collisionImage.collisionDelegate = self
        //Add collision behavior to animator
        animator.addBehavior(collisionImage)
        
        //Adding Square collision
        collisionSquare = UICollisionBehavior(items: [])
        collisionSquare.collisionMode = .items
        collisionSquare.addBoundary(withIdentifier: "bottomWall" as NSString, for: UIBezierPath(rect: bottomWall.frame))
        collisionSquare.addBoundary(withIdentifier: "topWall" as NSString, for: UIBezierPath(rect: topWall.frame))
        collisionSquare.addBoundary(withIdentifier: "birdView1" as NSString, for: UIBezierPath(rect: birdView1.frame))
        collisionSquare.collisionDelegate = self
        animator.addBehavior(collisionSquare)
        
        //Adding UIImageView of birds for itterations
        birdImageViews = [self.bird1, self.bird2, self.bird3, self.bird4, self.bird5]
        
        //Start timer to detect collision
        if self.viewTimer == nil {
            viewTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(checkForCollision), userInfo: nil, repeats: true)
        }
        
        self.runLevelTimer()
        self.getLevel()
        self.createObstacles()
    }
    
    override func viewWillLayoutSubviews() {
        self.checkForCollision()
    }
    
    override func viewDidLayoutSubviews() {
        print("viewDidLayoutSubviews called")
    }
    
    override func updateFocusIfNeeded() {
        print("updateFocusIfNeeded")
    }
    
    func createPanGestureRecognizer(targetView: UIView) {
        let panGesture = UIPanGestureRecognizer(target: self, action:(#selector(self.handleGesture(_:))))
        targetView.addGestureRecognizer(panGesture)
    }
    
    @objc func handleGesture(_ panGesture: UIPanGestureRecognizer) {
        // get translation
        let translation = panGesture.translation(in: view)
        let velocity = panGesture.velocity(in: panGesture.view?.superview)
        
        let x = velocity.x;
        let y = velocity.y;
        
        var angle = atan2(y, x) * 180.0 / 3.14159;
        if (angle < 0) {
            angle = angle + 360.0
        }
        
        var redY:CGFloat = btnAim.frame.origin.y + translation.y
        var redX:CGFloat = btnAim.frame.origin.x + translation.x
        if (redY < 250 && redY > 120) && (redX < 120 && redX > 40) {
            btnAim.frame = CGRect.init(origin: CGPoint.init(x: redX, y: redY), size: self.btnAim.frame.size)
        }

        if panGesture.state == UIGestureRecognizer.State.ended {
            // add something you want to happen when the Label Panning has ended
            self.addSquare(point: translation, angle: angle)
        }
    }
    
    func addSquare(point : CGPoint, angle : CGFloat) {
        //let square = UIImageView(frame: CGRect(x: point.x, y: point.y, width: 20, height: 20))
        let ball = UIImageView(frame: CGRect(x: self.btnAim.frame.origin.x, y: self.btnAim.frame.origin.y, width: 40, height: 40))
        //square.backgroundColor = UIColor.gray
        ball.image = UIImage.init(named: "ball")
        view.addSubview(ball)
        ballsArray.append(ball)
        
        /*let barrier = UIView(frame: CGRect(x: 0, y: 300, width: 130, height: 20))
        barrier.backgroundColor = UIColor.red
        view.addSubview(barrier)*/
        
        //gravity = UIGravityBehavior(items: [square])
        //gravity.gravityDirection = CGVector.init(dx: 0, dy: -1)
        //animator.addBehavior(gravity)
        
        /*force = UIPushBehavior.init(items: [square], mode: .continuous)
        //force.angle = CGFloat(Double.pi / 2)
        force.angle = (angle / 58.5)
        force.magnitude = 10
        animator.addBehavior(force)
        
        collisionSquare.addItem(square)
        collisionImage.addItem(square)*/
        
        /*collisionSquare.addItem(square)
        collisionSquare.addBoundary(withIdentifier: "bottomWall" as NSString, for: UIBezierPath(rect: bottomWall.frame))
        collisionSquare.addBoundary(withIdentifier: "topWall" as NSString, for: UIBezierPath(rect: topWall.frame))
        collisionSquare.addBoundary(withIdentifier: "birdView1" as NSString, for: UIBezierPath(rect: birdView1.frame))
        //collision.addBoundary(withIdentifier: "bird1" as NSString, for: UIBezierPath(rect: bird1.convert(bird1.frame, from: self.view)))
        
        collisionSquare.collisionMode = .boundaries
        
        collisionSquare.collisionDelegate = self
        animator.addBehavior(collisionSquare)*/
        
        let itemBehaviour = UIDynamicItemBehavior(items: [ball])
        itemBehaviour.elasticity = 0.9
        //itemBehaviour.addLinearVelocity(point, for: square)
        itemBehaviour.addLinearVelocity(CGPoint.init(x: point.x * 5, y: point.y * 5), for: ball)
        //itemBehaviour.addAngularVelocity(angle, for: square)
        animator.addBehavior(itemBehaviour)
        
        let boundaries = UICollisionBehavior(items: [ball])
        boundaries.addBoundary(withIdentifier: "leftBoundary" as NSCopying, from: CGPoint(x: 0,y: 0), to: CGPoint(x: 0, y: self.view.frame.height))
        boundaries.addBoundary(withIdentifier: "middleBoundary" as NSCopying, from: CGPoint(x:0 ,y: self.view.frame.height), to: CGPoint(x: self.view.frame.width, y: self.view.frame.height))
        boundaries.addBoundary(withIdentifier: "TopBoundary" as NSCopying, from: CGPoint(x: 0,y: 0), to: CGPoint(x: self.view.frame.width, y: 0))
        boundaries.collisionMode = .everything
        animator.addBehavior(boundaries)
        
        //Adding obstacle
        if let obstacleImg = self.obstacleImgView {
            boundaries.addBoundary(withIdentifier: "barrier" as NSCopying, for: UIBezierPath(rect: obstacleImg.frame))
        }
        
        for item in self.ballsArray{
            let ballToBall = UICollisionBehavior(items: [item])
            ballToBall.collisionMode = .everything
            animator.addBehavior(ballToBall)
        }
        
        let ballToBall = UICollisionBehavior(items: [ball])
        ballToBall.collisionMode = .everything
        animator.addBehavior(ballToBall)
    }
    
    @objc func animateBirds() {
        let randoxIndex = Int.random(in: 0..<self.birdImageViews.count - 1)
        let image = self.birdsImagesArray[randoxIndex]
        birdImageViews[randoxIndex].image = nil
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
            self.birdImageViews[randoxIndex].image = image
        }
    }
    
    @objc func checkForCollision(){
        for eachBall in self.ballsArray {
            for eachBird in birdImageViews {
                if eachBall.frame.intersects(eachBird.frame) && !eachBird.isHidden {
                    eachBird.isHidden = true
                    let image : UIImage = UIImage(named:"collision")!
                    let collisionImageFrame : UIImageView = UIImageView.init(frame: eachBird.frame)
                    collisionImageFrame.image = image
                    //Vibrate device
                    AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                    //Play sound
                    self.play(sound: "ShortRing", ofType: .wav)
                    UIView.animate(withDuration: 1.0) {
                        self.view.addSubview(collisionImageFrame)
                    }
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
                        UIView.animate(withDuration: 2.0, animations: {
                            collisionImageFrame.removeFromSuperview()
                        }) { (completed) in
                            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
                                UIView.animate(withDuration: 2.0) {
                                    let randomInt = Int.random(in: 0..<self.imagesArray.count - 1)
                                    eachBird.image = self.imagesArray[randomInt]
                                    eachBird.isHidden = false
                                    
                                }
                            }
                        }
                    }
                    /*DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
                        UIView.animate(withDuration: 2.0) {
                            eachBird.isHidden = false
                            
                        }
                    }*/
                    self.score += 1
                    self.lblScore.text = String(score)
                }
            }
        }
    }
}

extension ViewController {
    func collisionBehavior(_ behavior: UICollisionBehavior, beganContactFor item: UIDynamicItem, withBoundaryIdentifier identifier: NSCopying?, at p: CGPoint) {
        print("Boundary contact occurred - \(String(describing: identifier))")
        if identifier as! NSString == "bird1" {
            UIView.animate(withDuration: 0.3) {
                self.bird1.isHidden = true
                UIView.animate(withDuration: 0.3) {
                    self.bird1.isHidden = false
                    
                }
            }
        }
        
        if identifier as! NSString == "bird2" {
            UIView.animate(withDuration: 0.3) {
                self.bird2.isHidden = true
                UIView.animate(withDuration: 0.3) {
                    self.bird2.isHidden = false
                    
                }
            }
        }
        
        if identifier as! NSString == "bird3" {
            UIView.animate(withDuration: 0.3) {
                self.bird3.isHidden = true
                UIView.animate(withDuration: 0.3) {
                    self.bird3.isHidden = false
                    
                }
            }
        }
        
        if identifier as! NSString == "bird4" {
            UIView.animate(withDuration: 0.3) {
                self.bird4.isHidden = true
                UIView.animate(withDuration: 0.3) {
                    self.bird4.isHidden = false
                    
                }
            }
        }
        
        if identifier as! NSString == "bird5" {
            UIView.animate(withDuration: 0.3) {
                self.bird5.isHidden = true
                UIView.animate(withDuration: 0.3) {
                    self.bird5.isHidden = false
                    
                }
            }
        }
        
        if identifier as! NSString == "birdView1" {
            self.birdView1.removeFromSuperview()
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
                self.view.addSubview(self.birdView1)
            }
            /*UIView.animate(withDuration: 3.0) {
                self.birdView1.isHidden = true
                UIView.animate(withDuration: 3.0) {
                    self.birdView1.isHidden = false
                    
                }
            }*/
        }
    }
    
    func runLevelTimer(){
        if levelTimer == nil {
            self.levelTimer = Timer.scheduledTimer(timeInterval: 16.0, target: self, selector: #selector(levelUp), userInfo: nil, repeats: true)
        }
    }
    
    //Once the level timer over, this functionality will be call for result work.
    //Saving user score and level in
    @objc func levelUp() {
        //Save user score and level
        UserDefaults.standard.set(score, forKey: "userScore")
        UserDefaults.standard.set(lblLevel.text, forKey: "userLevel")
        
        
        //Turning off all timers
        if self.levelTimer != nil {
            self.levelTimer.invalidate()
        }
        if self.viewTimer != nil {
            self.viewTimer.invalidate()
        }
        if self.birdTimer != nil {
            self.birdTimer.invalidate()
        }
        
        if self.birdTimer != nil {
            self.birdTimer.invalidate()
        }
        
        let main = UIStoryboard(name: "Main", bundle: nil)
        let resultVC = main.instantiateViewController(withIdentifier: "GameOverVC") as? GameOVerViewController
        self.present(resultVC!, animated: true, completion: nil)
    }
    
    //Checking levels, configuring level text to label
    func getLevel(){
        if let level = UserDefaults.standard.string(forKey: "userLevel"){
            self.lblLevel.text = level
        } else {
            self.lblLevel.text = "1"
            UserDefaults.standard.set(self.lblLevel.text, forKey: "userLevel")
        }
    }
    
    //Creating obstacles for 2nd and 3rd level.
    func createObstacles(){
        let level = Int(self.lblLevel.text!)
        if level! > 1 {
            let obstacleImgName = "square.png"
            let image = UIImage(named: obstacleImgName)
            let obstacleImgView = UIImageView(image: image)
            //obstacleImgView.frame = CGRect(x: 265, y: 100, width: 200, height: 80)
            obstacleImgView.frame = CGRect(x: self.view.frame.height*0.7, y: view.frame.height*0.27, width: view.frame.width*0.3, height: view.frame.height*0.22)
            obstacleImgView.restorationIdentifier = "Obstacle"
            self.view.addSubview(obstacleImgView)
            self.obstacleImgView = obstacleImgView
        }
        
    }
    
    func play(sound: String, ofType type: SoundExtension) {
       if let soundID = notificationSoundLookupTable[sound] {
          AudioServicesPlaySystemSound(soundID)
       } else {
          if let soundURL : CFURL = Bundle.main.url(forResource: sound,       withExtension: type.rawValue) as CFURL? {
             var soundID  : SystemSoundID = 0
             let osStatus : OSStatus = AudioServicesCreateSystemSoundID(soundURL, &soundID)
             if osStatus == kAudioServicesNoError {
                AudioServicesPlaySystemSound(soundID);
                notificationSoundLookupTable[sound] = (soundID)
             }else{
                // This happens in exceptional cases
                // Handle it with no sound or retry
             }
          }
       }
    }
}

enum SoundExtension : String{
   case caf
   case aif
   case wav
}
